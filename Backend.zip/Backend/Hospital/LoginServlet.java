package Hospital;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.write("{\"status\":\"error\",\"message\":\"Use POST method for login\"}");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        PrintWriter out = null;
        try {
            out = response.getWriter();
            
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            if (email == null || password == null || email.trim().isEmpty() || password.trim().isEmpty()) {
                out.write("{\"status\":\"error\",\"message\":\"Email and password are required\"}");
                return;
            }

            try (Connection con = MyConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement("SELECT id, name, email, password FROM register WHERE email = ?")) {
                
                ps.setString(1, email.trim().toLowerCase());
                
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String dbPassword = rs.getString("password");
                        
                        if (password.equals(dbPassword)) {
                            HttpSession session = request.getSession(true);
                            session.setAttribute("userId", rs.getInt("id"));
                            session.setAttribute("userName", rs.getString("name"));
                            session.setAttribute("userEmail", rs.getString("email"));
                            
                            out.write("{\"status\":\"success\",\"message\":\"Login successful\",\"name\":\"" + 
                                    escapeJson(rs.getString("name")) + "\",\"email\":\"" + 
                                    escapeJson(rs.getString("email")) + "\"}");
                        } else {
                            out.write("{\"status\":\"error\",\"message\":\"Invalid email or password\"}");
                        }
                    } else {
                        out.write("{\"status\":\"error\",\"message\":\"Invalid email or password\"}");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                out.write("{\"status\":\"error\",\"message\":\"Database error: " + escapeJson(e.getMessage()) + "\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (out != null) {
                out.write("{\"status\":\"error\",\"message\":\"Server error\"}");
            }
        }
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}