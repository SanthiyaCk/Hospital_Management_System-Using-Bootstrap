package Hospital;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class MyConnection {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/healthcare_db";
    private static final String JDBC_USER = "root";   
    private static final String JDBC_PASS = "santhiya@#123";

    public static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
            
            // Create table if not exists
            createTableIfNotExists(conn);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
    
    private static void createTableIfNotExists(Connection conn) {
        try {
            Statement stmt = conn.createStatement();
            String sql = "CREATE TABLE IF NOT EXISTS appointments (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "appointment_id VARCHAR(50) UNIQUE NOT NULL, " +
                "patient_name VARCHAR(100) NOT NULL, " +
                "email VARCHAR(100) NOT NULL, " +
                "phone VARCHAR(20) NOT NULL, " +
                "gender VARCHAR(10) NOT NULL, " +
                "age INT NOT NULL, " +
                "department VARCHAR(50) NOT NULL, " +
                "doctor_name VARCHAR(100) NOT NULL, " +
                "appointment_date DATE NOT NULL, " +
                "appointment_time TIME NOT NULL, " +
                "symptoms TEXT, " +
                "status VARCHAR(20) DEFAULT 'Scheduled', " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                ")";
            stmt.executeUpdate(sql);
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}