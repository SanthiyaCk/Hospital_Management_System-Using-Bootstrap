package Hospital;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Servlet implementation class AppointmentServlet
 */
@WebServlet("/AppointmentServlet")
public class AppointmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AppointmentServlet() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        String action = request.getParameter("action");
        
        if ("checkAvailability".equals(action)) {
            checkAvailability(request, response);
        } else {
            response.getWriter().append("Served at: ").append(request.getContextPath());
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        saveAppointment(request, response);
    }
    
    private void checkAvailability(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        
        try {
            String doctor = request.getParameter("doctor");
            String date = request.getParameter("date");
            String time = request.getParameter("time");
            
            Connection conn = MyConnection.getConnection();
            String sql = "SELECT COUNT(*) as count FROM appointments WHERE doctor_name = ? AND appointment_date = ? AND appointment_time = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, doctor);
            pstmt.setString(2, date);
            pstmt.setString(3, time);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                int count = rs.getInt("count");
                if (count > 0) {
                    out.print("{\"available\": false, \"message\": \"This time slot is already booked\"}");
                } else {
                    out.print("{\"available\": true, \"message\": \"Slot available\"}");
                }
            }
            
            rs.close();
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"available\": false, \"message\": \"Error checking availability: " + e.getMessage() + "\"}");
        }
    }
    
    private void saveAppointment(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        
        try {
            // Get form parameters
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String gender = request.getParameter("gender");
            int age = Integer.parseInt(request.getParameter("age"));
            String department = request.getParameter("department");
            String doctor = request.getParameter("doctor");
            String date = request.getParameter("date");
            String time = request.getParameter("time");
            String symptoms = request.getParameter("symptoms");
            
            // Generate appointment ID
            String appointmentId = generateAppointmentId();
            
            Connection conn = MyConnection.getConnection();
            String sql = "INSERT INTO appointments (appointment_id, patient_name, email, phone, gender, age, department, doctor_name, appointment_date, appointment_time, symptoms, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Scheduled', NOW())";
            
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, appointmentId);
            pstmt.setString(2, name);
            pstmt.setString(3, email);
            pstmt.setString(4, phone);
            pstmt.setString(5, gender);
            pstmt.setInt(6, age);
            pstmt.setString(7, department);
            pstmt.setString(8, doctor);
            pstmt.setString(9, date);
            pstmt.setString(10, time);
            pstmt.setString(11, symptoms);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                out.print("{\"status\": \"success\", \"appointmentId\": \"" + appointmentId + "\", \"message\": \"Appointment booked successfully\"}");
            } else {
                out.print("{\"status\": \"error\", \"message\": \"Failed to save appointment\"}");
            }
            
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"status\": \"error\", \"message\": \"Error saving appointment: " + e.getMessage() + "\"}");
        }
    }
    
    private String generateAppointmentId() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        return "APT" + sdf.format(new Date()) + (int)(Math.random() * 1000);
    }
}