package Hospital;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.regex.Pattern;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    private static final Pattern PASSWORD_PATTERN = Pattern.compile("^(?=.*[A-Za-z])(?=.*\\d).{8,}$");

    @Override
    public void init() throws ServletException {
        super.init();
        System.out.println("RegisterServlet initialized");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Set character encoding
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        PrintWriter out = response.getWriter();
        
        try {
            // Get parameters
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            
            System.out.println("Registration attempt - Name: " + name + ", Email: " + email);

            // Validation
            if (name == null || name.trim().isEmpty()) {
                sendError(out, "Name field is required");
                return;
            }
            
            if (email == null || email.trim().isEmpty()) {
                sendError(out, "Email field is required");
                return;
            }
            
            if (password == null || password.trim().isEmpty()) {
                sendError(out, "Password field is required");
                return;
            }
            
            // Trim values
            name = name.trim();
            email = email.trim().toLowerCase();
            password = password.trim();
            
            if (!EMAIL_PATTERN.matcher(email).matches()) {
                sendError(out, "Invalid email format");
                return;
            }
            
            if (!PASSWORD_PATTERN.matcher(password).matches()) {
                sendError(out, "Password must be at least 8 characters with letters and numbers");
                return;
            }

            // Database operations
            Connection con = null;
            PreparedStatement checkStmt = null;
            PreparedStatement insertStmt = null;
            ResultSet rs = null;
            
            try {
                con = MyConnection.getConnection();
                System.out.println("Database connection established");
                
                // Check if email exists
                String checkSql = "SELECT id FROM register WHERE email = ?";
                checkStmt = con.prepareStatement(checkSql);
                checkStmt.setString(1, email);
                rs = checkStmt.executeQuery();
                
                if (rs.next()) {
                    sendError(out, "Email already registered");
                    return;
                }
                
                // Close result set and statement before reusing
                rs.close();
                checkStmt.close();

                // Insert new user
                String insertSql = "INSERT INTO register (name, email, password) VALUES (?, ?, ?)";
                insertStmt = con.prepareStatement(insertSql);
                insertStmt.setString(1, name);
                insertStmt.setString(2, email);
                insertStmt.setString(3, password);
                
                int rows = insertStmt.executeUpdate();
                if (rows > 0) {
                    sendSuccess(out, "Registration successful! You can now login.");
                } else {
                    sendError(out, "Failed to register user");
                }
                
            } catch (Exception e) {
                System.err.println("Database error in RegisterServlet: " + e.getMessage());
                e.printStackTrace();
                sendError(out, "Database error: " + e.getMessage());
            } finally {
                // Close resources in reverse order
                try { if (rs != null) rs.close(); } catch (Exception e) { e.printStackTrace(); }
                try { if (checkStmt != null) checkStmt.close(); } catch (Exception e) { e.printStackTrace(); }
                try { if (insertStmt != null) insertStmt.close(); } catch (Exception e) { e.printStackTrace(); }
                try { if (con != null) con.close(); } catch (Exception e) { e.printStackTrace(); }
            }
            
        } catch (Exception e) {
            System.err.println("Unexpected error in RegisterServlet: " + e.getMessage());
            e.printStackTrace();
            sendError(out, "Server error: " + e.getMessage());
        }
    }

    private void sendSuccess(PrintWriter out, String message) {
        out.write("{\"status\":\"success\",\"message\":\"" + escapeJson(message) + "\"}");
        System.out.println("Registration success: " + message);
    }

    private void sendError(PrintWriter out, String message) {
        out.write("{\"status\":\"error\",\"message\":\"" + escapeJson(message) + "\"}");
        System.out.println("Registration error: " + message);
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.write("{\"status\":\"error\",\"message\":\"Use POST method for registration\"}");
    }
}