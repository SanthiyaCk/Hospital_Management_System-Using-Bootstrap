 
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const loginOverlay = document.getElementById('loginOverlay');
    const closeLogin = document.getElementById('closeLogin');
    const signInBtn = document.getElementById('signInBtn');
    const signUpBtn = document.getElementById('signUpBtn');
    const loginContainer = document.getElementById('loginContainer');
    const userGreeting = document.getElementById('userGreeting');
    const loginErrorMsg = document.getElementById('loginErrorMsg') || 
                         createErrorElement('loginForm', 'loginErrorMsg');
    const signupErrorMsg = document.getElementById('signupErrorMsg') || 
                          createErrorElement('signupForm', 'signupErrorMsg');

    // Create error message element if it doesn't exist
    function createErrorElement(parentId, elementId) {
        const parent = document.getElementById(parentId);
        if (!parent) return null;
        
        const errorElement = document.createElement('div');
        errorElement.id = elementId;
        errorElement.className = 'error-message';
        errorElement.style.color = 'red';
        errorElement.style.marginTop = '10px';
        parent.appendChild(errorElement);
        return errorElement;
    }

    // In-memory user storage
    const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers')) || [];

    // Helper function to toggle overlay visibility
    function toggleOverlay(show) {
        loginOverlay.style.display = show ? 'flex' : 'none';
        document.body.style.overflow = show ? 'hidden' : 'auto';
    }

    // Show login overlay
    if (loginBtn) {
        loginBtn.addEventListener('click', function() {
            toggleOverlay(true);
            loginContainer.classList.remove('right-panel-active');
            if (loginErrorMsg) loginErrorMsg.textContent = '';
        });
    }

    // Close login overlay
    if (closeLogin) {
        closeLogin.addEventListener('click', function() {
            toggleOverlay(false);
            if (loginErrorMsg) loginErrorMsg.textContent = '';
            if (signupErrorMsg) signupErrorMsg.textContent = '';
        });
    }

    // Switch to sign up
    if (signUpBtn) {
        signUpBtn.addEventListener('click', function() {
            loginContainer.classList.add('right-panel-active');
            if (signupErrorMsg) signupErrorMsg.textContent = '';
        });
    }

    // Switch to sign in
    if (signInBtn) {
        signInBtn.addEventListener('click', function() {
            loginContainer.classList.remove('right-panel-active');
            if (loginErrorMsg) loginErrorMsg.textContent = '';
        });
    }

    // Password visibility toggle functionality
    function setupPasswordToggles() {
        document.querySelectorAll('.toggle-password').forEach(icon => {
            icon.addEventListener('click', function() {
                const input = this.previousElementSibling || 
                             this.closest('.input-group')?.querySelector('input[type="password"], input[type="text"]');
                
                if (!input) return;

                if (input.type === 'password') {
                    input.type = 'text';
                    if (this.classList.contains('fa-eye')) {
                        this.classList.replace('fa-eye', 'fa-eye-slash');
                    } else {
                        this.classList.remove('fa-eye');
                        this.classList.add('fa-eye-slash');
                    }
                    this.setAttribute('aria-label', 'Hide password');
                } else {
                    input.type = 'password';
                    if (this.classList.contains('fa-eye-slash')) {
                        this.classList.replace('fa-eye-slash', 'fa-eye');
                    } else {
                        this.classList.remove('fa-eye-slash');
                        this.classList.add('fa-eye');
                    }
                    this.setAttribute('aria-label', 'Show password');
                }

                const cursorPosition = input.selectionStart;
                input.focus();
                input.setSelectionRange(cursorPosition, cursorPosition);
            });
        });
    }

    // Set up password toggles
    setupPasswordToggles();

    // Login Form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = loginForm.querySelector('input[type="email"]').value.trim();
            const password = loginForm.querySelector('input[type="password"]').value.trim();

            if (loginErrorMsg) loginErrorMsg.textContent = '';

            if (!email || !password) {
                if (loginErrorMsg) loginErrorMsg.textContent = 'Please fill in all fields';
                return;
            }

            const user = registeredUsers.find(u => u.email === email && u.password === password);
            
            if (user) {
                // Store login state
                sessionStorage.setItem('isLoggedIn', 'true');
                sessionStorage.setItem('currentUser', JSON.stringify(user));
                
                alert('Login successful!');
                toggleOverlay(false);
                
                if (userGreeting) {
                    userGreeting.textContent = `Hello, ${user.name || email.split('@')[0]}`;
                }
                if (loginBtn) loginBtn.style.display = 'none';
                if (logoutBtn) logoutBtn.style.display = 'block';
            } else {
                if (loginErrorMsg) {
                    loginErrorMsg.textContent = 'Invalid email or password. Please try again or register.';
                }
            }
        });
    }

    // Signup Form
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = signupForm.querySelector('input[type="text"]').value.trim();
            const email = signupForm.querySelector('input[type="email"]').value.trim();
            const password = signupForm.querySelector('input[type="password"]').value.trim();

            if (signupErrorMsg) signupErrorMsg.textContent = '';

            if (!name || !email || !password) {
                if (signupErrorMsg) signupErrorMsg.textContent = 'Please fill in all fields';
                return;
            }

            const userExists = registeredUsers.some(u => u.email === email);
            
            if (userExists) {
                if (signupErrorMsg) {
                    signupErrorMsg.textContent = 'Email already registered. Please log in instead.';
                }
            } else {
                const newUser = { name, email, password };
                registeredUsers.push(newUser);
                localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
                
                alert('Registration successful! Please log in.');
                loginContainer.classList.remove('right-panel-active');
                signupForm.reset();
            }
        });
    }

    // Check login state on page load
    function checkLoginState() {
        const isLoggedIn = sessionStorage.getItem('isLoggedIn') === 'true';
        const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
        
        if (isLoggedIn && currentUser) {
            if (userGreeting) {
                userGreeting.textContent = `Hello, ${currentUser.name || currentUser.email.split('@')[0]}`;
            }
            if (loginBtn) loginBtn.style.display = 'none';
            if (logoutBtn) logoutBtn.style.display = 'block';
        } else {
            if (userGreeting) userGreeting.textContent = 'Hello, Guest';
            if (loginBtn) loginBtn.style.display = 'block';
            if (logoutBtn) logoutBtn.style.display = 'none';
        }
    }

    // Secure Logout with confirmation
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            // Create confirmation modal
            const modal = document.createElement('div');
            modal.style.position = 'fixed';
            modal.style.top = '0';
            modal.style.left = '0';
            modal.style.width = '100%';
            modal.style.height = '100%';
            modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
            modal.style.display = 'flex';
            modal.style.justifyContent = 'center';
            modal.style.alignItems = 'center';
            modal.style.zIndex = '1000';
            
            modal.innerHTML = `
                <div style="background: white; padding: 20px; border-radius: 8px; text-align: center;">
                    <h3>Confirm Logout</h3>
                    <p>Are you sure you want to log out?</p>
                    <div style="margin-top: 20px;">
                        <button id="confirmLogout" style="
                            background: #dc3545;
                            color: white;
                            border: none;
                            padding: 8px 16px;
                            border-radius: 4px;
                            margin-right: 10px;
                            cursor: pointer;
                        ">Log Out</button>
                        <button id="cancelLogout" style="
                            background: #6c757d;
                            color: white;
                            border: none;
                            padding: 8px 16px;
                            border-radius: 4px;
                            cursor: pointer;
                        ">Cancel</button>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            document.getElementById('confirmLogout').addEventListener('click', function() {
                // Clear session data
                sessionStorage.removeItem('isLoggedIn');
                sessionStorage.removeItem('currentUser');
                
                // Update UI
                if (userGreeting) userGreeting.textContent = 'Hello, Guest';
                if (loginBtn) loginBtn.style.display = 'block';
                if (logoutBtn) logoutBtn.style.display = 'none';
                
                // Remove modal
                document.body.removeChild(modal);
            });
            
            document.getElementById('cancelLogout').addEventListener('click', function() {
                document.body.removeChild(modal);
            });
        });
    }

    // Initialize login state
    checkLoginState();
});

    // Back to top button
    window.addEventListener('scroll', function() {
        const backToTop = document.getElementById('backToTop');
        if (window.pageYOffset > 300) {
            backToTop.style.display = 'flex';
            backToTop.classList.add('show');
        } else {
            backToTop.style.display = 'none';
            backToTop.classList.remove('show');
        }
    });

    document.getElementById('backToTop').addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // Update live wait times
    function updateWaitTimes() {
        document.querySelectorAll('.live-time').forEach(el => {
            const interval = parseInt(el.getAttribute('data-interval'));
            const randomChange = Math.floor(Math.random() * 5) - 2; // -2 to +2
            let newTime = interval + randomChange;
            newTime = Math.max(5, newTime); // Minimum 5 minutes
            el.textContent = newTime;
        });
        
        const now = new Date();
        const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        document.querySelectorAll('.update-time').forEach(el => {
            el.textContent = timeString;
        });
    }

    // Update wait times every 30 seconds
    setInterval(updateWaitTimes, 30000);

    // Initialize wait times
    updateWaitTimes();

// Department doctors data
const doctorsData = {
    'Cardiology': [
        { name: 'Dr. Anjali Reo', specialization: 'Cardiologist', experience: '9 years', image: 'IMAGE/doctor1.jpg' },
        { name: 'Dr. John Smith', specialization: 'Cardiac Surgeon', experience: '10 years', image: 'IMAGE/doctor2.jpg' }
    ],
    'Pediatrics': [
        { name: 'Dr. Karthik Nair', specialization: 'Pediatrician', experience: '10 years', image: 'IMAGE/doctor3.jpg' },
        { name: 'Dr. Rajesh Patel', specialization: 'Neonatologist', experience: '8 years', image: 'IMAGE/doctor4.jpg' },
        { name: 'Dr. Meena Desai', specialization: 'Neonatologist', experience: '12 years', image: 'IMAGE/doctor5.jpg' }
    ],
    'Orthopedics': [
        { name: 'Dr. Neha Gupta', specialization: 'Orthopedic Surgeon', experience: '18 years', image: 'IMAGE/doctor6.jpg' },
        { name: 'Dr. Vikram Singh', specialization: 'Sports Medicine', experience: '9 years', image: 'IMAGE/doctor7.png' }
    ],
    'Gynecology': [
        { name: 'Dr. Shilpa Reddy', specialization: 'Gynecologist', experience: '12 years', image: 'IMAGE/doctor8.jpg' },
        { name: 'Dr. Raj Kapoor', specialization: 'OB/GYN', experience: '10 years', image: 'IMAGE/doctor9.jpg' }
    ],
    'Neurology': [
        { name: 'Dr. Arjun Mehta', specialization: 'Neurologist', experience: '16 years', image: 'IMAGE/doctor10.jpg' },
        { name: 'Dr. Nandini Joshi', specialization: 'Neurosurgeon', experience: '20 years', image: 'IMAGE/doctor11.jpg' }
    ],
    'Dermatology': [
        { name: 'Dr. Riya Malhotra', specialization: 'Dermatologist', experience: '12 years', image: 'IMAGE/doctor12.jpg' },
        { name: 'Dr. Sameer Khan', specialization: 'Cosmetic Dermatology', experience: '8 years', image: 'IMAGE/doctor13.jpg' }
    ],
    'ENT': [
        { name: 'Dr. Pooja Iyer', specialization: 'ENT Specialist', experience: '9 years', image: 'IMAGE/doctor14.jpg' },
        { name: 'Dr. Aditya Verma', specialization: 'ENT Specialist', experience: '8 years', image: 'IMAGE/doctor15.jpg' },
        { name: 'Dr. Priya Kulkarni', specialization: 'Audiologist', experience: '10 years', image: 'IMAGE/doctor16.jpg' }
    ],
    'Psychiatry': [
        { name: 'Dr. Sanjay Kapoor', specialization: 'Psychiatrist', experience: '10 years', image: 'IMAGE/doctor17.jpg' },
        { name: 'Dr. Vikramathithan', specialization: 'Clinical Psychologist', experience: '12 years', image: 'IMAGE/doctor18.jpg' }
    ],
    'Anesthesiology': [
        { name: 'Dr. Swathi Menon', specialization: 'Anesthesiologist', experience: '15 years', image: 'IMAGE/doctor19.jpg' },
        { name: 'Dr. Rahul Deshpande', specialization: 'Pain Management', experience: '10 years', image: 'IMAGE/doctor20.jpg' }
    ],
    'Plastic_Surgery': [
        { name: 'Dr. Rohit Khanna', specialization: 'Plastic Surgeon', experience: '12 years', image: 'IMAGE/doctor21.jpg' },
        { name: 'Dr. Natasha Roy', specialization: 'Cosmetic Surgeon', experience: '8 years', image: 'IMAGE/doctor22.jpg' }
    ],
    'Physiotherapy': [
        { name: 'Dr. Ayesha Khan', specialization: 'Physiotherapist', experience: '10 years', image: 'IMAGE/doctor23.jpg' },
        { name: 'Dr. Varun Malhotra', specialization: 'Sports Physio', experience: '4 years', image: 'IMAGE/doctor24.jpg' },
        { name: 'Dr. Priyanka Chopra', specialization: 'Rehabilitation', experience: '6 years', image: 'IMAGE/doctor25.jpg' }
    ],
    'General_Medical': [
        { name: 'Dr. Deepika Kapoore', specialization: 'General Physician', experience: '10 years', image: 'IMAGE/doctor26.jpg' },
        { name: 'Dr. Amit Sharma', specialization: 'Family Medicine', experience: '7 years', image: 'IMAGE/doctor27.jpg' },
        { name: 'Dr. Ravi Kumar', specialization: 'Primary Care', experience: '6 years', image: 'IMAGE/doctor28.jpg' }
    ]
};

// Show doctor overlay with responsive card layout
window.showDoctorOverlay = function(department) {
    const overlay = document.getElementById('doctorOverlay');
    const deptTitle = document.getElementById('deptTitle');
    const doctorCards = document.getElementById('doctorCards');
    
    if (!overlay || !deptTitle || !doctorCards) {
        console.error('Required overlay elements not found');
        return;
    }

    // Set department title
    deptTitle.textContent = `${department} Department Doctors`;
    doctorCards.innerHTML = '';
    
    // Check if department exists
    if (!doctorsData[department]) {
        doctorCards.innerHTML = `<div class="col-12 text-center py-4">
            <p>No doctors found in this department</p>
        </div>`;
        overlay.style.display = 'flex';
        document.body.style.overflow = 'hidden';
        return;
    }

    // Determine column class based on number of doctors
    const doctorCount = doctorsData[department].length;
    const colClass = doctorCount <= 2 ? 'col-md-6' : 'col-md-4';
    
    // Create doctor cards
    doctorsData[department].forEach(doctor => {
        const card = document.createElement('div');
        card.className = `${colClass} mb-4`;
        card.innerHTML = `
            <div class="card h-100 doctor-card">
                <img src="${doctor.image}" class="card-img-top doctor-image" alt="${doctor.name}">
                <div class="card-body">
                    <h5 class="card-title">${doctor.name}</h5>
                    <p class="card-text"><strong>Specialization:</strong> ${doctor.specialization}</p>
                    <p class="card-text"><strong>Experience:</strong> ${doctor.experience}</p>
                    <button class="btn btn-primary book-appointment w-100"
                            data-doctor='${JSON.stringify(doctor)}'
                            data-department="${department}">
                        Book Appointment
                    </button>
                </div>
            </div>
        `;
        doctorCards.appendChild(card);
    });
    
    overlay.style.display = 'flex';
    document.body.style.overflow = 'hidden';
};

// Hide doctor overlay
window.hideDoctorOverlay = function() {
    const overlay = document.getElementById('doctorOverlay');
    if (overlay) {
        overlay.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
};

// Initialize event listeners
document.addEventListener('DOMContentLoaded', function() {
    const overlay = document.getElementById('doctorOverlay');
    const closeBtn = document.getElementById('closeDoctorOverlay');
    
    // Click outside content to close
    if (overlay) {
        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) {
                hideDoctorOverlay();
            }
        });
    }
    
    // Close button click
    if (closeBtn) {
        closeBtn.addEventListener('click', hideDoctorOverlay);
    }
    
    // Listen for book appointment button clicks
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('book-appointment')) {
        const doctor = JSON.parse(e.target.getAttribute('data-doctor'));
        const department = e.target.getAttribute('data-department');

        // Save doctor & department to sessionStorage
        sessionStorage.setItem('selectedDoctor', doctor.name);
        sessionStorage.setItem('selectedDepartment', department);

        // Redirect to Appointment page
        window.location.href = "Appointment.html";
    }
});

});
    // Scroll functionality for departments and tips
    window.scrollSection = function(containerId, scrollAmount) {
        const container = document.getElementById(containerId);
        container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    };

    // Health calculators
    document.getElementById('calculate-bmi').addEventListener('click', function() {
        const height = parseFloat(document.getElementById('bmi-height').value) / 100; // convert to meters
        const weight = parseFloat(document.getElementById('bmi-weight').value);
        
        if (height && weight) {
            const bmi = (weight / (height * height)).toFixed(1);
            let category = '';
            
            if (bmi < 18.5) category = 'Underweight';
            else if (bmi < 25) category = 'Normal weight';
            else if (bmi < 30) category = 'Overweight';
            else category = 'Obese';
            
            const resultDiv = document.getElementById('bmi-result');
            resultDiv.innerHTML = `Your BMI: <span class="text-primary">${bmi}</span> (${category})`;
            resultDiv.style.display = 'block';
        }
    });

    document.getElementById('calculate-calories').addEventListener('click', function() {
        const age = parseInt(document.getElementById('calorie-age').value);
        const activity = parseFloat(document.getElementById('calorie-activity').value);
        
        if (age) {
            // Simple calculation (not accounting for gender, weight, etc.)
            const baseCalories = 2000;
            const adjustedCalories = Math.round(baseCalories * activity);
            
            const resultDiv = document.getElementById('calorie-result');
            resultDiv.innerHTML = `Estimated daily calorie needs: <span class="text-primary">${adjustedCalories}</span> kcal`;
            resultDiv.style.display = 'block';
        }
    });

    document.getElementById('calculate-due-date').addEventListener('click', function() {
        const lmp = document.getElementById('due-date-lmp').value;
        const cycleLength = parseInt(document.getElementById('due-date-cycle').value) || 28;
        
        if (lmp) {
            const lmpDate = new Date(lmp);
            const dueDate = new Date(lmpDate);
            dueDate.setDate(lmpDate.getDate() + 280 - (28 - cycleLength));
            
            const options = { year: 'numeric', month: 'long', day: 'numeric' };
            const resultDiv = document.getElementById('due-date-result');
            resultDiv.innerHTML = `Estimated due date: <span class="text-primary">${dueDate.toLocaleDateString(undefined, options)}</span>`;
            resultDiv.style.display = 'block';
        }
    });

    // Function to scroll the tips container
        function scrollSection(sectionId, offset) {
            const section = document.getElementById(sectionId);
            section.scrollBy({ left: offset, behavior: 'smooth' });
        }

        // Tip data - in a real application, this might come from a server
        const tipData = {
            heart: {
                title: "Eat Healthy Food",
                image: "IMAGE/Herat_Food.jpg",
                description: "Maintain a balanced diet with fruits, vegetables, and whole grains for optimal health.",
                benefits: [
                    "Reduces risk of heart disease by up to 30%",
                    "Helps maintain healthy blood pressure",
                    "Supports healthy weight management",
                    "Provides essential nutrients for overall health",
                    "Lowers cholesterol levels"
                ],
                tips: [
                    "Fill half your plate with fruits and vegetables",
                    "Choose whole grains over refined carbohydrates",
                    "Limit saturated and trans fats",
                    "Include lean protein sources",
                    "Reduce sodium intake to less than 2,300 mg per day"
                ]
            },
            diabetes: {
                title: "Manage Diabetes",
                image: "IMAGE/Diabeties.jpg",
                description: "Monitor blood sugar levels and follow your doctor's advice for better control.",
                benefits: [
                    "Reduces risk of diabetes complications",
                    "Helps maintain stable energy levels",
                    "Supports cardiovascular health",
                    "Prevents nerve damage",
                    "Improves overall quality of life"
                ],
                tips: [
                    "Check blood sugar levels regularly",
                    "Follow a balanced meal plan",
                    "Take medications as prescribed",
                    "Engage in regular physical activity",
                    "Attend regular medical check-ups"
                ]
            },
            checkups: {
                title: "Regular Checkups",
                image: "IMAGE/checkup.jpg",
                description: "Preventive care can detect health issues early when they're most treatable.",
                benefits: [
                    "Early detection of health problems",
                    "Better management of chronic conditions",
                    "Improved treatment outcomes",
                    "Lower healthcare costs in the long run",
                    "Peace of mind about your health status"
                ],
                tips: [
                    "Schedule annual physical examinations",
                    "Keep track of your family medical history",
                    "Don't skip recommended screenings",
                    "Discuss any health concerns openly with your doctor",
                    "Follow up on test results and recommendations"
                ]
            },
            sleep: {
                title: "Quality Sleep",
                image: "IMAGE/Sleep.jpg",
                description: "Aim for 7-9 hours of sleep each night for optimal health and recovery.",
                benefits: [
                    "Improves memory and cognitive function",
                    "Supports immune system function",
                    "Enhances mood and emotional regulation",
                    "Promotes cellular repair and recovery",
                    "Helps maintain healthy weight"
                ],
                tips: [
                    "Maintain a consistent sleep schedule",
                    "Create a relaxing bedtime routine",
                    "Make your bedroom sleep-friendly",
                    "Limit screen time before bed",
                    "Avoid caffeine and large meals before bedtime"
                ]
            },
            exercise: {
                title: "Regular Exercise",
                image: "IMAGE/Regular_Exercise.jpeg",
                description: "30 minutes of moderate activity most days improves cardiovascular health.",
                benefits: [
                    "Strengthens heart and cardiovascular system",
                    "Improves circulation and oxygen flow",
                    "Helps maintain healthy weight",
                    "Reduces risk of chronic diseases",
                    "Boosts mood and reduces stress"
                ],
                tips: [
                    "Find activities you enjoy to stay motivated",
                    "Mix cardio, strength training, and flexibility exercises",
                    "Start slowly and gradually increase intensity",
                    "Set realistic fitness goals",
                    "Listen to your body and rest when needed"
                ]
            },
            hydration: {
                title: "Stay Hydrated",
                image: "IMAGE/Stay_Hydrated.jpg",
                description: "Drink at least 8 glasses of water daily to maintain body functions.",
                benefits: [
                    "Regulates body temperature",
                    "Lubricates joints and tissues",
                    "Supports kidney function and waste removal",
                    "Improves skin health and appearance",
                    "Enhances physical performance"
                ],
                tips: [
                    "Carry a water bottle with you throughout the day",
                    "Drink water before, during, and after exercise",
                    "Eat water-rich fruits and vegetables",
                    "Monitor urine color as a hydration indicator",
                    "Limit sugary drinks and excessive caffeine"
                ]
            }
        };

        // Handle modal show event
        const tipModal = document.getElementById('tipModal');
        tipModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget; // Button that triggered the modal
            const tipType = button.getAttribute('data-tip'); // Extract info from data-tip attribute
            const tip = tipData[tipType];
            
            // Update the modal's content
            const modalTitle = tipModal.querySelector('.modal-title');
            const modalBody = tipModal.querySelector('.modal-body');
            
            modalTitle.textContent = tip.title;
            
            modalBody.innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <img src="${tip.image}" class="img-fluid detail-img" alt="${tip.title}">
                        <p>${tip.description}</p>
                    </div>
                    <div class="col-md-6">
                        <h5><i class="fas fa-heart text-danger me-2"></i> Benefits</h5>
                        <ul class="benefits-list">
                            ${tip.benefits.map(benefit => `<li><span class="tip-icon"><i class="fas fa-check"></i></span> ${benefit}</li>`).join('')}
                        </ul>
                    </div>
                </div>
                <div class="mt-4">
                    <h5><i class="fas fa-lightbulb text-warning me-2"></i> Practical Tips</h5>
                    <div class="row">
                        ${tip.tips.map(tip => `
                            <div class="col-sm-6 mb-2">
                                <div class="d-flex">
                                    <div class="me-3"><i class="fas fa-arrow-right text-primary"></i></div>
                                    <div>${tip}</div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        });

// -------------------- GLOBALS --------------------
window.selectedEvent = null;
window.events = {
  diabetes: {
    title: "Free Diabetes Screening",
    date: "October 15, 2023",
    time: "9:00 AM - 4:00 PM",
    location: "Main Hospital Campus, Building A, Floor 3",
    description: "Get your blood sugar levels checked and learn about prevention.",
    detailsHTML: "<ul><li>Free blood glucose testing</li><li>BMI & BP checks</li><li>Consultation with specialists</li></ul>"
  },
  vaccination: {
    title: "Pediatric Vaccination Camp",
    date: "November 22, 2023",
    time: "10:00 AM - 2:00 PM",
    location: "Children's Wing, Rainbow Room",
    description: "All recommended childhood vaccines in a kid-friendly setup.",
    detailsHTML: "<ul><li>Routine childhood vaccines</li><li>Flu shots</li><li>Pediatrician consultation</li></ul>"
  }
};

let eventModal = null;

// -------------------- BOOTSTRAP + EMAILJS INIT --------------------
window.addEventListener("DOMContentLoaded", function () {
  // Modal setup
  eventModal = new bootstrap.Modal(document.getElementById("eventModal"));

  // ✅ Initialize EmailJS with your public key
  emailjs.init("Cv1uaXfgefdLI5Eeu");

  // Attach form submit
  const form = document.getElementById("eventRegistrationForm");
  if (form) {
    form.addEventListener("submit", handleSubmit);
  }
});

// -------------------- UI ACTIONS --------------------
window.showEventDetails = function (eventType) {
  window.selectedEvent = eventType;
  const ev = window.events[eventType];
  if (!ev || !eventModal) return;

  document.getElementById("eventModalLabel").textContent = ev.title;
  document.getElementById("eventModalBody").innerHTML = `
    <h4>${ev.title}</h4>
    <p><strong>Date:</strong> ${ev.date}</p>
    <p><strong>Time:</strong> ${ev.time}</p>
    <p><strong>Location:</strong> ${ev.location}</p>
    <p>${ev.description}</p>
    <div>${ev.detailsHTML}</div>
  `;
  eventModal.show();
};

window.showRegistrationCard = function () {
  if (!window.selectedEvent) {
    alert("Please choose an event first.");
    return;
  }
  const ev = window.events[window.selectedEvent];
  document.getElementById("eventTitle").textContent = ev.title;
  document.getElementById("registrationCard").style.display = "block";
  if (eventModal) eventModal.hide();
  document.getElementById("registrationCard").scrollIntoView({ behavior: "smooth" });
};

window.closeRegistrationCard = function () {
  document.getElementById("registrationCard").style.display = "none";
  document.getElementById("eventRegistrationForm").reset();
};

window.resetPage = function () {
  document.getElementById("confirmationCard").style.display = "none";
  document.getElementById("eventRegistrationForm").reset();
  window.selectedEvent = null;
  document.getElementById("Health").scrollIntoView({ behavior: "smooth" });
};

// -------------------- FORM SUBMIT + EMAIL --------------------
function handleSubmit(e) {
  e.preventDefault();

  if (!window.selectedEvent) {
    alert("Please select an event before registering!");
    return;
  }

  const ev = window.events[window.selectedEvent];
  document.getElementById("loadingOverlay").style.display = "flex";

  // Collect form values
  const firstName = document.getElementById("firstName").value.trim();
  const lastName = document.getElementById("lastName").value.trim();
  const email = document.getElementById("email").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const participants = document.getElementById("participants").value;
  const notes = document.getElementById("notes").value.trim();

  // ✅ User confirmation email params
  const templateParamsUser = {
    to_name: `${firstName} ${lastName}`,
    to_email: email,
    event_title: ev.title,
    event_date: ev.date,
    event_time: ev.time,
    event_location: ev.location,
    participants,
    phone,
    notes: notes || "No additional notes provided",
  };

  // ✅ Hospital notification email params
  const templateParamsHospital = {
    to_name: "Hospix Medical Team",
    to_email: "santhiyasanthiya88838@gmail.com", // fixed hospital email
    event_title: ev.title,
    event_date: ev.date,
    event_time: ev.time,
    event_location: ev.location,
    participants,
    phone,
    registrant_name: `${firstName} ${lastName}`,
    registrant_email: email,
    notes: notes || "No additional notes provided",
  };

  // ✅ Send both emails
  Promise.all([
    emailjs.send("service_1y7ld2k", "template_ticiv6b", templateParamsUser), // to user
    emailjs.send("service_1y7ld2k", "template_vbrnu6e", templateParamsHospital), // to hospital
  ])
    .then(() => {
      document.getElementById("loadingOverlay").style.display = "none";

      // Show confirmation card
      document.getElementById("registrationCard").style.display = "none";
      document.getElementById("confirmationCard").style.display = "block";
      document.getElementById("confirmedEvent").textContent = ev.title;
      document.getElementById("userEmail").textContent = email;
    })
    .catch((error) => {
      document.getElementById("loadingOverlay").style.display = "none";
      alert("Error sending email(s): " + JSON.stringify(error));
    });
}
