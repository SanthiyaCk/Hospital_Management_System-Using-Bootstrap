const AppointmentSystem = (function() {
        // Configuration constants
        const CONFIG = {
            EMAILJS: {
                PUBLIC_KEY: "4wvhgwuWFxU_3H796",
                SERVICE_ID: "service_y1jw278",
                TEMPLATE_ID: "template_emjn4wg",      // For admin notifications
                PATIENT_TEMPLATE_ID: "template_r72lbtt" // For patient confirmations
            },
            HOSPITAL_INFO: {
                NAME: "HEALTHCARE Hospital",
                ADDRESS: "HealthCare Hospital, Coimbatore, Tamil Nadu",
                PHONE: "+91 93612 35395",
                EMAIL: "healthcare1966@gmail.com"
            }
        };

        // Department-Doctor mapping and schedules
        const DATA = {
            DOCTORS_BY_DEPARTMENT: {
                "Cardiology": ["Dr. Anjali Rao", "Dr. John Smith"],
                "Pediatrics": ["Dr. Karthik Nair", "Dr. Rajesh Patel", "Dr. Meena Desai"],
                "Orthopedics": ["Dr. Neha Gupta", "Dr. Vikram Singh"],
                "Gynecology": ["Dr. Shilpa Reddy", "Dr. Raj Kapoor"],
                "Neurology": ["Dr. Arjun Mehta", "Dr. Nandini Joshi"],
                "Dermatology": ["Dr. Riya Malhotra", "Dr. Sameer Khan"],
                "ENT": ["Dr. Pooja Iyer", "Dr. Aditya Verma", "Dr. Priya Kulkarni"],
                "Psychiatry": ["Dr. Sanjay Kapoor", "Dr. Vikramathithan"],
                "Anesthesiology": ["Dr. Swati Menon", "Dr. Rahul Deshpande"],
                "Plastic Surgery": ["Dr. Rohit Khanna", "Dr. Natasha Roy"],
                "Physiotherapy": ["Dr. Ayesha Khan", "Dr. Varun Malhotra", "Dr. Priyanka Chopra"],
                "General Medicine": ["Dr. Deepika Kapoor", "Dr. Amit Sharma", "Dr. Ravi Kumar"]
            },
            DOCTOR_SCHEDULES: {
                "Dr. Anjali Rao": ["Monday: 9:00 AM - 4:00 PM", "Wednesday: 9:00 AM - 4:00 PM", "Friday: 9:00 AM - 4:00 PM"],
                "Dr. John Smith": ["Tuesday: 10:00 AM - 5:00 PM", "Thursday: 10:00 AM - 5:00 PM", "Saturday: 10:00 AM - 2:00 PM"],
                "Dr. Karthik Nair": ["Monday: 8:00 AM - 3:00 PM", "Wednesday: 8:00 AM - 3:00 PM", "Friday: 8:00 AM - 3:00 PM"],
                "Dr. Rajesh Patel": ["Tuesday: 9:00 AM - 4:00 PM", "Thursday: 9:00 AM - 4:00 PM", "Saturday: 9:00 AM - 1:00 PM"],
                "Dr. Meena Desai": ["Monday: 10:00 AM - 5:00 PM", "Wednesday: 10:00 AM - 5:00 PM", "Friday: 10:00 AM - 5:00 PM"],
                "Dr. Neha Gupta": ["Tuesday: 8:00 AM - 3:00 PM", "Thursday: 8:00 AM - 3:00 PM", "Saturday: 8:00 AM - 12:00 PM"],
                "Dr. Vikram Singh": ["Monday: 9:00 AM - 4:00 PM", "Wednesday: 9:00 AM - 4:00 PM", "Friday: 9:00 AM - 4:00 PM"],
                "Dr. Shilpa Reddy": ["Tuesday: 10:00 AM - 5:00 PM", "Thursday: 10:00 AM - 5:00 PM", "Saturday: 10:00 AM - 2:00 PM"],
                "Dr. Raj Kapoor": ["Monday: 8:00 AM - 3:00 PM", "Wednesday: 8:00 AM - 3:00 PM", "Friday: 8:00 AM - 3:00 PM"],
                "Dr. Arjun Mehta": ["Tuesday: 9:00 AM - 4:00 PM", "Thursday: 9:00 AM - 4:00 PM", "Saturday: 9:00 AM - 1:00 PM"],
                "Dr. Nandini Joshi": ["Monday: 10:00 AM - 5:00 PM", "Wednesday: 10:00 AM - 5:00 PM", "Friday: 10:00 AM - 5:00 PM"],
                "Dr. Riya Malhotra": ["Tuesday: 8:00 AM - 3:00 PM", "Thursday: 8:00 AM - 3:00 PM", "Saturday: 8:00 AM - 12:00 PM"],
                "Dr. Sameer Khan": ["Monday: 9:00 AM - 4:00 PM", "Wednesday: 9:00 AM - 4:00 PM", "Friday: 9:00 AM - 4:00 PM"],
                "Dr. Pooja Iyer": ["Tuesday: 10:00 AM - 5:00 PM", "Thursday: 10:00 AM - 5:00 PM", "Saturday: 10:00 AM - 2:00 PM"],
                "Dr. Aditya Verma": ["Monday: 8:00 AM - 3:00 PM", "Wednesday: 8:00 AM - 3:00 PM", "Friday: 8:00 AM - 3:00 PM"],
                "Dr. Priya Kulkarni": ["Tuesday: 9:00 AM - 4:00 PM", "Thursday: 9:00 AM - 4:00 PM", "Saturday: 9:00 AM - 1:00 PM"],
                "Dr. Sanjay Kapoor": ["Monday: 10:00 AM - 5:00 PM", "Wednesday: 10:00 AM - 5:00 PM", "Friday: 10:00 AM - 5:00 PM"],
                "Dr. Vikramathithan": ["Tuesday: 8:00 AM - 3:00 PM", "Thursday: 8:00 AM - 3:00 PM", "Saturday: 8:00 AM - 12:00 PM"],
                "Dr. Swati Menon": ["Monday: 9:00 AM - 4:00 PM", "Wednesday: 9:00 AM - 4:00 PM", "Friday: 9:00 AM - 4:00 PM"],
                "Dr. Rahul Deshpande": ["Tuesday: 10:00 AM - 5:00 PM", "Thursday: 10:00 AM - 5:00 PM", "Saturday: 10:00 AM - 2:00 PM"],
                "Dr. Rohit Khanna": ["Monday: 8:00 AM - 3:00 PM", "Wednesday: 8:00 AM - 3:00 PM", "Friday: 8:00 AM - 3:00 PM"],
                "Dr. Natasha Roy": ["Tuesday: 9:00 AM - 4:00 PM", "Thursday: 9:00 AM - 4:00 PM", "Saturday: 9:00 AM - 1:00 PM"],
                "Dr. Ayesha Khan": ["Monday: 10:00 AM - 5:00 PM", "Wednesday: 10:00 AM - 5:00 PM", "Friday: 10:00 AM - 5:00 PM"],
                "Dr. Varun Malhotra": ["Tuesday: 8:00 AM - 3:00 PM", "Thursday: 8:00 AM - 3:00 PM", "Saturday: 8:00 AM - 12:00 PM"],
                "Dr. Priyanka Chopra": ["Monday: 9:00 AM - 4:00 PM", "Wednesday: 9:00 AM - 4:00 PM", "Friday: 9:00 AM - 4:00 PM"],
                "Dr. Deepika Kapoor": ["Tuesday: 10:00 AM - 5:00 PM", "Thursday: 10:00 AM - 5:00 PM", "Saturday: 10:00 AM - 2:00 PM"],
                "Dr. Amit Sharma": ["Monday: 8:00 AM - 3:00 PM", "Wednesday: 8:00 AM - 3:00 PM", "Friday: 8:00 AM - 3:00 PM"],
                "Dr. Ravi Kumar": ["Tuesday: 9:00 AM - 4:00 PM", "Thursday: 9:00 AM - 4:00 PM", "Saturday: 9:00 AM - 1:00 PM"]
            }
        };

        // DOM Elements
        const elements = {
            form: document.getElementById("appointmentForm"),
            nameInput: document.getElementById("name"),
            emailInput: document.getElementById("email"),
            phoneInput: document.getElementById("phone"),
            genderSelect: document.getElementById("gender"),
            ageInput: document.getElementById("age"),
            departmentSelect: document.getElementById("department"),
            doctorSelect: document.getElementById("doctor"),
            dateInput: document.getElementById("date"),
            timeInput: document.getElementById("time"),
            symptomsTextarea: document.getElementById("symptoms"),
            doctorTimingInfo: document.getElementById("doctorTimingInfo"),
            errorMessageDiv: document.getElementById("errorMessage"),
            submitBtn: document.querySelector(".btn-submit"),
            confirmationMessage: document.getElementById("confirmationMessage"),
            successModal: document.getElementById("successModal") ? 
                new bootstrap.Modal(document.getElementById('successModal')) : null
        };

        // Initialize the system
        async function init() {
            try {
                // Validate DOM elements
                if (!validateDOMElements()) {
                    throw new Error("Required DOM elements not found");
                }

                // Set minimum date to today
                const today = new Date().toISOString().split('T')[0];
                elements.dateInput.min = today;
                elements.dateInput.value = today;

                // Initialize EmailJS
                await initEmailJS();
                
                // Set up event listeners
                setupEventListeners();

            } catch (error) {
                console.error("Initialization error:", error);
                showError("System initialization failed. Please refresh the page.");
            }
        }

        // Pre-fill doctor and department if selected from Home page
const selectedDoctor = sessionStorage.getItem('selectedDoctor');
const selectedDepartment = sessionStorage.getItem('selectedDepartment');

if (selectedDepartment) {
    // Set department
    elements.departmentSelect.value = selectedDepartment;
    updateDoctorOptions(selectedDepartment);

    // Enable date input since department is chosen
    elements.dateInput.disabled = false;

    if (selectedDoctor) {
        // Set doctor
        elements.doctorSelect.value = selectedDoctor;
        displayDoctorSchedule(selectedDoctor);

        // Enable time input since doctor is chosen
        elements.timeInput.disabled = false;

        // Refresh available times for today
        updateAvailableTimes(selectedDoctor, elements.dateInput.value);
    }
}

        // Validate required DOM elements
        function validateDOMElements() {
            const requiredElements = [
                'form', 'nameInput', 'emailInput', 'phoneInput', 'genderSelect', 
                'ageInput', 'departmentSelect', 'doctorSelect', 'dateInput', 
                'timeInput', 'errorMessageDiv', 'submitBtn'
            ];
            
            return requiredElements.every(key => {
                if (!elements[key]) {
                    console.error(`Missing required element: ${key}`);
                    return false;
                }
                return true;
            });
        }

        // Initialize EmailJS with retry logic
        async function initEmailJS(retryCount = 0) {
            try {
                if (typeof emailjs === 'undefined') {
                    throw new Error("EmailJS library not loaded");
                }
                
                if (!CONFIG.EMAILJS.PUBLIC_KEY) {
                    throw new Error("EmailJS public key not configured");
                }
                
                await emailjs.init(CONFIG.EMAILJS.PUBLIC_KEY);
                console.log("EmailJS initialized successfully");
                return true;
            } catch (error) {
                console.error("EmailJS init error:", error);
                if (retryCount < 3) {
                    await new Promise(resolve => setTimeout(resolve, 1000 * (retryCount + 1)));
                    return initEmailJS(retryCount + 1);
                }
                throw error;
            }
        }

        // === Prefill from Doctor page (supports both sessionStorage and localStorage JSON) ===
(function prefillFromDoctorPage() {
  let selectedDoctor = null;
  let selectedDepartment = null;

  // Try Doctor.js JSON in localStorage
  try {
    const raw = localStorage.getItem('selectedDoctorData');
    if (raw) {
      const obj = JSON.parse(raw);
      selectedDoctor = obj?.name || obj?.doctor || null;
      selectedDepartment = obj?.department || null;
    }
  } catch (_) {}

  // Fallback: simple keys in sessionStorage
  if (!selectedDoctor) selectedDoctor = sessionStorage.getItem('selectedDoctor');
  if (!selectedDepartment) selectedDepartment = sessionStorage.getItem('selectedDepartment');

  if (!selectedDepartment) return; // nothing to prefill

  // Set department and populate doctors list
  elements.departmentSelect.value = selectedDepartment;
  updateDoctorOptions(selectedDepartment); // enables the doctor select

  // Enable date input once department is chosen
  elements.dateInput.disabled = false;

  // If a doctor was sent, select it (only if it exists in options)
  if (selectedDoctor) {
    const hasOption = Array.from(elements.doctorSelect.options)
      .some(o => o.value === selectedDoctor);
    if (hasOption) {
      elements.doctorSelect.value = selectedDoctor;
      displayDoctorSchedule(selectedDoctor);
      elements.timeInput.disabled = false;
      updateAvailableTimes(selectedDoctor, elements.dateInput.value);
    }
  }

  // One-time use – prevent stale values
  localStorage.removeItem('selectedDoctorData');
  sessionStorage.removeItem('selectedDoctor');
  sessionStorage.removeItem('selectedDepartment');
})();

        // Set up all event listeners
        function setupEventListeners() {
            // Department change
            elements.departmentSelect.addEventListener("change", function() {
                const department = this.value;
                updateDoctorOptions(department);
                clearDoctorSchedule();
                resetTimeInput();
                // Enable date input when department is selected
                elements.dateInput.disabled = !department;
            });

            // Doctor change
            elements.doctorSelect.addEventListener("change", function() {
                const doctor = this.value;
                if (doctor) {
                    displayDoctorSchedule(doctor);
                    updateAvailableTimes(doctor, elements.dateInput.value);
                } else {
                    clearDoctorSchedule();
                    resetTimeInput();
                }
                // Enable time input when doctor is selected
                elements.timeInput.disabled = !doctor;
            });

            // Date change
            elements.dateInput.addEventListener("change", function() {
                const doctor = elements.doctorSelect.value;
                if (doctor) {
                    updateAvailableTimes(doctor, this.value);
                }
            });

            // Form submission
            elements.form.addEventListener("submit", handleFormSubmit);

            // Real-time validation
            elements.emailInput.addEventListener("input", validateEmail);
            elements.phoneInput.addEventListener("input", validatePhone);
        }

        // Update doctor options based on selected department
        function updateDoctorOptions(department) {
            const doctorSelect = elements.doctorSelect;
            
            // Clear existing options
            doctorSelect.innerHTML = '';
            
            // Add default option
            const defaultOption = document.createElement('option');
            defaultOption.value = '';
            defaultOption.textContent = 'Select Doctor';
            defaultOption.selected = true;
            defaultOption.disabled = true;
            doctorSelect.appendChild(defaultOption);
            
            if (!department) {
                doctorSelect.disabled = true;
                return;
            }
            
            // Get doctors for the selected department
            const doctors = DATA.DOCTORS_BY_DEPARTMENT[department] || [];
            
            if (doctors.length === 0) {
                doctorSelect.disabled = true;
                return;
            }
            
            // Add each doctor as an option
            doctors.forEach(doctor => {
                const option = document.createElement('option');
                option.value = doctor;
                option.textContent = doctor;
                doctorSelect.appendChild(option);
            });
            
            doctorSelect.disabled = false;
        }

        // Display doctor's schedule
        function displayDoctorSchedule(doctor) {
            if (!elements.doctorTimingInfo) return;
            
            const schedule = DATA.DOCTOR_SCHEDULES[doctor] || [];
            const doctorName = doctor.replace('Dr. ', '');
            
            elements.doctorTimingInfo.innerHTML = `
                <h4>Dr. ${doctorName}'s Weekly Schedule</h4>
                <ul class="schedule-list">
                    ${schedule.map(time => `<li>${time}</li>`).join('')}
                </ul>
            `;
            elements.doctorTimingInfo.classList.remove('d-none');
        }

        function clearDoctorSchedule() {
            if (elements.doctorTimingInfo) {
                elements.doctorTimingInfo.innerHTML = '';
                elements.doctorTimingInfo.classList.add('d-none');
            }
        }

        // Update available times based on doctor and date
        function updateAvailableTimes(doctor, dateString) {
            if (!elements.timeInput) return;
            if (!doctor || !dateString) {
                resetTimeInput();
                return;
            }
            
            const date = new Date(dateString);
            const dayOfWeek = date.toLocaleDateString('en-US', { weekday: 'long' });
            const doctorSchedule = DATA.DOCTOR_SCHEDULES[doctor] || [];
            
            // Find schedule for the selected day
            const daySchedule = doctorSchedule.find(s => s.startsWith(dayOfWeek));
            
            // Clear existing options
            resetTimeInput();
            
            if (!daySchedule) {
                addTimeOption('', 'Doctor not available on selected day');
                elements.timeInput.disabled = true;
                return;
            }
            
            // Extract available times (e.g., "9:00 AM - 4:00 PM")
            const times = daySchedule.split(': ')[1].split(' - ');
            const startTimeStr = times[0].trim();
            const endTimeStr = times[1].trim();
            
            // Convert to 24-hour format for calculations
            const startTime = convertTo24Hour(startTimeStr);
            const endTime = convertTo24Hour(endTimeStr);
            
            // Add default option
            addTimeOption('', 'Select a time');
            
            // Generate time slots (every 30 minutes)
            let currentHour = startTime.hours;
            let currentMinute = startTime.minutes;
            const endHour = endTime.hours;
            const endMinute = endTime.minutes;
            
            while (currentHour < endHour || (currentHour === endHour && currentMinute <= endMinute)) {
                // Format as 24-hour time for the value (e.g., "14:30")
                const time24hr = `${String(currentHour).padStart(2, '0')}:${String(currentMinute).padStart(2, '0')}`;
                // Format as 12-hour time for display (e.g., "2:30 PM")
                const time12hr = formatTo12Hour(currentHour, currentMinute);
                
                addTimeOption(time24hr, time12hr);
                
                // Increment by 30 minutes
                currentMinute += 30;
                if (currentMinute >= 60) {
                    currentMinute = 0;
                    currentHour += 1;
                }
            }
            
            elements.timeInput.disabled = false;
        }

        // Helper: Convert "9:00 AM" to { hours: 9, minutes: 0 }
        function convertTo24Hour(timeStr) {
            if (!timeStr) return { hours: 0, minutes: 0 };
            
            const [time, period] = timeStr.split(' ');
            const [hoursStr, minutesStr] = time.split(':');
            
            let hours = parseInt(hoursStr, 10) || 0;
            const minutes = parseInt(minutesStr, 10) || 0;
            
            if (period === 'PM' && hours < 12) hours += 12;
            if (period === 'AM' && hours === 12) hours = 0;
            
            return { hours, minutes };
        }

        // Helper: Format 24-hour time to 12-hour (e.g., 14:30 → "2:30 PM")
        function formatTo12Hour(hours, minutes) {
            const period = hours >= 12 ? 'PM' : 'AM';
            const displayHours = hours % 12 || 12;
            const displayMinutes = String(minutes).padStart(2, '0');
            return `${displayHours}:${displayMinutes} ${period}`;
        }

        // Add option to time dropdown
        function addTimeOption(value, text) {
            if (!elements.timeInput) return;
            const option = document.createElement('option');
            option.value = value;
            option.textContent = text;
            elements.timeInput.appendChild(option);
        }

        // Reset time dropdown
        function resetTimeInput() {
            if (!elements.timeInput) return;
            elements.timeInput.innerHTML = '';
            addTimeOption('', 'Select Your Timing');
            elements.timeInput.disabled = true;
        }

        // Form validation
        function validateForm() {
            let isValid = true;
            clearErrors();

            // Validate name
            if (!elements.nameInput.value.trim()) {
                elements.nameInput.classList.add('is-invalid');
                isValid = false;
            }

            // Validate email
            if (!validateEmail()) {
                isValid = false;
            }

            // Validate phone
            if (!validatePhone()) {
                isValid = false;
            }
            
            // Validate gender
            if (!elements.genderSelect.value) {
                elements.genderSelect.classList.add('is-invalid');
                isValid = false;
            }
            
            // Validate age
            const age = elements.ageInput.value;
            if (!age || isNaN(age) || age < 0 || age > 120) {
                elements.ageInput.classList.add('is-invalid');
                isValid = false;
            }

            // Validate department
            if (!elements.departmentSelect.value) {
                elements.departmentSelect.classList.add('is-invalid');
                isValid = false;
            }

            // Validate doctor
            if (!elements.doctorSelect.value) {
                elements.doctorSelect.classList.add('is-invalid');
                isValid = false;
            }

            // Validate date
            if (!elements.dateInput.value) {
                elements.dateInput.classList.add('is-invalid');
                isValid = false;
            }

            // Validate time
            if (!elements.timeInput.value || elements.timeInput.disabled) {
                elements.timeInput.classList.add('is-invalid');
                isValid = false;
            }

            return isValid;
        }

        function validateEmail() {
            const email = elements.emailInput.value.trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (!emailRegex.test(email)) {
                elements.emailInput.classList.add('is-invalid');
                return false;
            }
            
            elements.emailInput.classList.remove('is-invalid');
            return true;
        }

        function validatePhone() {
            const phone = elements.phoneInput.value.trim();
            const phoneRegex = /^[0-9]{10,15}$/;
            
            if (!phoneRegex.test(phone)) {
                elements.phoneInput.classList.add('is-invalid');
                return false;
            }
            
            elements.phoneInput.classList.remove('is-invalid');
            return true;
        }

        // Clear all error states
        function clearErrors() {
            const invalidElements = elements.form.querySelectorAll('.is-invalid');
            invalidElements.forEach(el => el.classList.remove('is-invalid'));
            
            if (elements.errorMessageDiv) {
                elements.errorMessageDiv.textContent = '';
                elements.errorMessageDiv.classList.add('d-none');
            }
        }

        // Show error message
        function showError(message) {
            if (elements.errorMessageDiv) {
                elements.errorMessageDiv.textContent = message;
                elements.errorMessageDiv.classList.remove('d-none');
                // Scroll to error message
                elements.errorMessageDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }

        // Set loading state
        function setLoadingState(isLoading) {
            if (elements.submitBtn) {
                elements.submitBtn.disabled = isLoading;
                const icon = elements.submitBtn.querySelector('i');
                if (icon) {
                    icon.className = isLoading ? 'fas fa-spinner fa-spin me-2' : 'far fa-paper-plane me-2';
                }
                elements.submitBtn.innerHTML = isLoading 
                    ? `<i class="fas fa-spinner fa-spin me-2"></i>Processing...` 
                    : `<i class="far fa-paper-plane me-2"></i>Book Appointment`;
            }
        }

        // Get form data as an object
        function getFormData() {
            return {
                name: elements.nameInput.value.trim(),
                email: elements.emailInput.value.trim(),
                phone: elements.phoneInput.value.trim(),
                gender: elements.genderSelect.value,
                age: elements.ageInput.value,
                department: elements.departmentSelect.value,
                doctor: elements.doctorSelect.value,
                date: elements.dateInput.value,
                time: elements.timeInput.value,
                symptoms: elements.symptomsTextarea.value.trim() || "Not specified"
            };
        }

        // Format date for display
        function formatAppointmentDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }

        // Get preparation instructions based on department
        function getPreparationInstructions(department) {
            const instructions = {
                "Cardiology": "Please avoid caffeine for 24 hours before your appointment.",
                "Pediatrics": "Bring your child's immunization records.",
                "Orthopedics": "Wear comfortable clothing that allows access to the affected area.",
                "Gynecology": "Come with a full bladder if ultrasound is needed.",
                "Neurology": "Bring any previous test results.",
                "Dermatology": "Avoid applying creams to affected areas.",
                "ENT": "No special preparation needed.",
                "Psychiatry": "Make notes of your symptoms and concerns.",
                "Anesthesiology": "Fast for 8 hours before procedure.",
                "Plastic Surgery": "Avoid smoking for 2 weeks before surgery.",
                "Physiotherapy": "Wear comfortable exercise clothing.",
                "General Medicine": "Bring a list of current medications."
            };
            return instructions[department] || "Please arrive 15 minutes early for your appointment.";
        }

        // Handle form submission
async function handleFormSubmit(event) {
    event.preventDefault();
    clearErrors();

    if (!validateForm()) {
        showError("Please correct the highlighted fields before submitting.");
        return;
    }

    const formData = getFormData();

    // ✅ Check if appointment already exists
    const existingAppointments = JSON.parse(localStorage.getItem("appointments")) || [];
    const conflict = existingAppointments.find(app =>
        app.department === formData.department &&
        app.doctor === formData.doctor &&
        app.date === formData.date &&
        app.time === formData.time
    );

    if (conflict) {
    const today = normalizeDate(new Date());
    const formDate = normalizeDate(formData.date);

    if (formDate === today) {
        showError("❌ Today is unavailable, please book your appointment for tomorrow.");
    } else {
        showError("❌ This slot is already booked. Please choose another time.");
    }
    return;
}
function normalizeDate(date) {
    if (typeof date === 'string') {
        date = new Date(date);
    }
    return date.toISOString().split('T')[0];
}

    setLoadingState(true);

    try {
        // Save this appointment in localStorage ✅
        existingAppointments.push(formData);
        localStorage.setItem("appointments", JSON.stringify(existingAppointments));

        // Proceed with sending emails as before
        if (typeof emailjs === 'undefined' || !emailjs.init) {
            throw new Error("Email service not available");
        }

                // Prepare admin email data
                const adminEmailParams = {
                    to_email: CONFIG.HOSPITAL_INFO.EMAIL,
                    patient_name: formData.name,
                    patient_email: formData.email,
                    patient_phone: formData.phone,
                    gender: formData.gender,
                    age: formData.age,
                    appointment_date: formatAppointmentDate(formData.date),
                    appointment_time: formatTo12Hour(
                        parseInt(formData.time.split(':')[0]),
                        parseInt(formData.time.split(':')[1])
                    ),
                    doctor_name: formData.doctor,
                    department: formData.department,
                    symptoms: formData.symptoms,
                    hospital_name: CONFIG.HOSPITAL_INFO.NAME,
                    hospital_address: CONFIG.HOSPITAL_INFO.ADDRESS,
                    hospital_phone: CONFIG.HOSPITAL_INFO.PHONE
                };

                // Send admin notification
                const adminResponse = await emailjs.send(
                    CONFIG.EMAILJS.SERVICE_ID,
                    CONFIG.EMAILJS.TEMPLATE_ID,
                    adminEmailParams,
                    CONFIG.EMAILJS.PUBLIC_KEY
                );
                console.log("Admin email sent:", adminResponse);

                // Prepare patient confirmation data
                const patientEmailParams = {
                    to_email: formData.email,
                    patient_name: formData.name,
                    appointment_date: formatAppointmentDate(formData.date),
                    appointment_time: formatTo12Hour(
                        parseInt(formData.time.split(':')[0]),
                        parseInt(formData.time.split(':')[1])
                    ),
                    doctor_name: formData.doctor,
                    department: formData.department,
                    symptoms: formData.symptoms,
                    hospital_name: CONFIG.HOSPITAL_INFO.NAME,
                    hospital_address: CONFIG.HOSPITAL_INFO.ADDRESS,
                    hospital_phone: CONFIG.HOSPITAL_INFO.PHONE,
                    preparation_instructions: getPreparationInstructions(formData.department),
                    cancellation_policy: "Please cancel at least 24 hours in advance by calling our office."
                };

                // Send patient confirmation
                const patientResponse = await emailjs.send(
                    CONFIG.EMAILJS.SERVICE_ID,
                    CONFIG.EMAILJS.PATIENT_TEMPLATE_ID,
                    patientEmailParams,
                    CONFIG.EMAILJS.PUBLIC_KEY
                );
                console.log("Patient email sent:", patientResponse);
                
                // Show success message
                handleSuccess(formData);
                
            } catch (error) {
        console.error("Form submission error:", error);
        let errorMessage = "Failed to submit appointment. ";
        if (error.status === 422) {
            errorMessage += "Invalid data sent to email service. Please check all fields.";
        } else if (error.message.includes("Network Error")) {
            errorMessage += "Network issue. Please check your connection.";
        } else {
            errorMessage += "Please try again later.";
        }
        showError(errorMessage);
    } finally {
        setLoadingState(false);
    }
}

        // Handle successful form submission
        function handleSuccess(formData) {
            if (elements.confirmationMessage) {
                elements.confirmationMessage.innerHTML = `
                    <h4>Appointment Confirmed!</h4>
                    <p>Dear ${formData.name}, your appointment with ${formData.doctor} (${formData.department}) 
                    has been scheduled for ${formatAppointmentDate(formData.date)} at ${formatTo12Hour(
                        parseInt(formData.time.split(':')[0]),
                        parseInt(formData.time.split(':')[1])
                    )}.</p>
                    <p>A confirmation has been sent to ${formData.email}.</p>
                    <p><strong>Preparation Instructions:</strong> ${getPreparationInstructions(formData.department)}</p>
                `;
            }
            
            // Show modal
            if (elements.successModal) {
                elements.successModal.show();
            }
            
            // Reset form
            elements.form.reset();
            resetTimeInput();
            clearDoctorSchedule();
            elements.dateInput.disabled = true;
            elements.doctorSelect.disabled = true;
            // Reset date to today
            const today = new Date().toISOString().split('T')[0];
            elements.dateInput.value = today;
        }

        return {
            init: init
        };
    })();

    // Initialize when DOM is loaded
    document.addEventListener('DOMContentLoaded', function() {
        AppointmentSystem.init();
    });
    