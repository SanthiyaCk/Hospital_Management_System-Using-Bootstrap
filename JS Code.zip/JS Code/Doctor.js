    // Doctor filtering functionality
    document.addEventListener('DOMContentLoaded', function() {
      const filterButtons = document.querySelectorAll('.filter-btn');
      const doctorCards = document.querySelectorAll('#doctors .col');
      const searchInput = document.getElementById('doctorSearch');
      const searchButton = document.getElementById('searchButton');

      // Filter by specialty
      filterButtons.forEach(button => {
        button.addEventListener('click', function() {
          const filter = this.getAttribute('data-filter');
          
          doctorCards.forEach(card => {
            if (filter === 'all' || card.getAttribute('data-specialty').includes(filter)) {
              card.style.display = 'block';
            } else {
              card.style.display = 'none';
            }
          });

          // Update active button
          filterButtons.forEach(btn => btn.classList.remove('active'));
          this.classList.add('active');
        });
      });

      // Search functionality
      searchButton.addEventListener('click', function() {
        const searchTerm = searchInput.value.toLowerCase();
        
        doctorCards.forEach(card => {
          const name = card.querySelector('.card-title').textContent.toLowerCase();
          const specialty = card.querySelector('.card-text').textContent.toLowerCase();
          
          if (name.includes(searchTerm) || specialty.includes(searchTerm)) {
            card.style.display = 'block';
          } else {
            card.style.display = 'none';
          }
        });
      });

      // Allow Enter key to trigger search
      searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
          searchButton.click();
        }
      });

      // Back to top button
      window.addEventListener('scroll', function() {
        const backToTopButton = document.getElementById('backToTop');
        if (window.pageYOffset > 300) {
          backToTopButton.style.display = 'block';
        } else {
          backToTopButton.style.display = 'none';
        }
      });

      document.getElementById('backToTop').addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });

      // User greeting functionality
      function userGreeting() {
        const user = localStorage.getItem("loggedInUser");
        const greeting = document.getElementById("userGreeting");
        const loginBtn = document.getElementById("loginBtn");
        const logoutBtn = document.getElementById("logoutBtn");

        if (user) {
          greeting.innerText = "Hello, " + user;
          loginBtn.style.display = "none";
          logoutBtn.style.display = "inline-block";
        } else {
          greeting.innerText = "Hello, Guest";
          loginBtn.style.display = "inline-block";
          logoutBtn.style.display = "none";
        }
      }

      function logout() {
        localStorage.removeItem("loggedInUser");
        userGreeting();
      }

      document.addEventListener("DOMContentLoaded", userGreeting);
    });


    // Doctor data - in a real application, this would come from a database
    const doctors = {
        1: {
            name: "Dr. Anjali Reo",
            image: "IMAGE/Doctor1.jpg",
            specialty: "Cardiology",
            specialization: "Cardiologist",
            experience: "9 years",
            education: "MBBS, MD - Cardiology, DM - Cardiology",
            expertise: "Heart disease treatment, Echocardiography, Angioplasty",
            languages: "English, Hindi, Marathi",
            availability: "Mon, Wed, Fri: 9am-4pm",
            about: "Dr. Anjali Reo is a renowned cardiologist with 9 years of experience in treating various heart conditions. She has performed over 500 successful angioplasties and is known for her compassionate patient care."
        },
        2: {
            name: "Dr. John Smith",
            image: "IMAGE/Doctor2.jpg",
            specialty: "Cardiology",
            specialization: "Cardiac Surgeon",
            experience: "10 years",
            education: "MBBS, MS - General Surgery, MCh - Cardio Thoracic Surgery",
            expertise: "Bypass surgery, Heart valve surgery, Aortic surgery",
            languages: "English, Spanish",
            availability: "Tue, Thu, Sat: 10am-6pm",
            about: "Dr. John Smith is a highly skilled cardiac surgeon with a decade of experience in performing complex heart surgeries. He has successfully performed over 1000 open heart surgeries with a 98% success rate."
        },
        3: {
            name: "Dr. Karthik Nair",
            image: "IMAGE/Doctor3.jpg",
            specialty: "Pediatrics",
            specialization: "Pediatrician",
            experience: "10 years",
            education: "MBBS, MD - Pediatrics",
            expertise: "Child healthcare, Vaccinations, Growth monitoring",
            languages: "English, Hindi, Malayalam, Tamil",
            availability: "Mon-Sat: 8am-3pm",
            about: "Dr. Karthik Nair is a dedicated pediatrician with 10 years of experience in child healthcare. He is known for his friendly approach with children and expertise in handling pediatric emergencies."
        },
        4: {
            name: "Dr. Rajesh Patel",
            image: "IMAGE/Doctor4.jpg",
            specialty: "Pediatrics",
            specialization: "Neonatologist",
            experience: "8 years",
            education: "MBBS, MD - Pediatrics, DM - Neonatology",
            expertise: "Newborn care, Preterm baby care, NICU management",
            languages: "English, Hindi, Gujarati",
            availability: "Mon-Fri: 9am-5pm",
            about: "Dr. Rajesh Patel is a skilled neonatologist with 8 years of experience in caring for newborns, especially premature infants. He has successfully managed over 500 critical neonatal cases."
        },
        5: {
            name: "Dr. Meena Desai",
            image: "IMAGE/Doctor5.jpg",
            specialty: "Pediatrics",
            specialization: "Neonatologist",
            experience: "12 years",
            education: "MBBS, MD - Pediatrics, DM - Neonatology",
            expertise: "Critical neonatal care, Preterm infant development, Neonatal surgery",
            languages: "English, Hindi, Gujarati",
            availability: "Tue, Thu, Sat: 10am-6pm",
            about: "Dr. Meena Desai is an experienced neonatologist with 12 years of expertise in critical neonatal care. She has published several research papers on preterm infant development and is highly regarded in her field."
        },
        6: {
            name: "Dr. Neha Gupta",
            image: "IMAGE/Doctor6.jpg",
            specialty: "Orthopedics",
            specialization: "Orthopedic Surgeon",
            experience: "18 years",
            education: "MBBS, MS - Orthopedics",
            expertise: "Joint replacements, Arthroscopic surgery, Sports injuries",
            languages: "English, Hindi, Punjabi",
            availability: "Mon, Wed, Fri: 9am-5pm",
            about: "Dr. Neha Gupta is a highly experienced orthopedic surgeon with 18 years of expertise in joint replacement surgeries. She has performed over 2000 successful joint replacements and is known for her precision and care."
        },
        7: {
            name: "Dr. Vikram Singh",
            image: "IMAGE/Doctor7.png",
            specialty: "Orthopedics",
            specialization: "Sports Medicine Specialist",
            experience: "9 years",
            education: "MBBS, MS - Orthopedics, Fellowship in Sports Medicine",
            expertise: "Sports injuries, Rehabilitation, Arthroscopy",
            languages: "English, Hindi",
            availability: "Tue, Thu, Sat: 10am-6pm",
            about: "Dr. Vikram Singh is a sports medicine specialist with 9 years of experience treating athletes and sports professionals. He has worked with several national sports teams and is an expert in minimally invasive procedures."
        },
        8: {
            name: "Dr. Shilpa Reddy",
            image: "IMAGE/Doctor8.jpg",
            specialty: "Gynecology",
            specialization: "Gynecologist",
            experience: "12 years",
            education: "MBBS, MD - Gynecology",
            expertise: "Women's health, Minimally invasive surgery, Menopause management",
            languages: "English, Hindi, Telugu",
            availability: "Mon-Fri: 9am-4pm",
            about: "Dr. Shilpa Reddy is a compassionate gynecologist with 12 years of experience in women's health. She specializes in minimally invasive procedures and has helped thousands of women with various health issues."
        },
        9: {
            name: "Dr. Raj Kapoor",
            image: "IMAGE/Doctor9.jpg",
            specialty: "Gynecology",
            specialization: "OB/GYN",
            experience: "10 years",
            education: "MBBS, MD - Obstetrics and Gynecology",
            expertise: "Pregnancy care, High-risk pregnancies, Fertility treatments",
            languages: "English, Hindi, Punjabi",
            availability: "Mon-Sat: 10am-5pm",
            about: "Dr. Raj Kapoor is an experienced OB/GYN with 10 years of expertise in pregnancy care and fertility treatments. He has successfully managed numerous high-risk pregnancies and is known for his empathetic approach."
        },
        10: {
            name: "Dr. Arjun Mehta",
            image: "IMAGE/Doctor10.jpg",
            specialty: "Neurology",
            specialization: "Neurologist",
            experience: "16 years",
            education: "MBBS, MD - General Medicine, DM - Neurology",
            expertise: "Brain disorders, Epilepsy, Stroke management",
            languages: "English, Hindi, Gujarati",
            availability: "Mon, Wed, Fri: 9am-5pm",
            about: "Dr. Arjun Mehta is a senior neurologist with 16 years of experience in treating complex brain disorders. He is an expert in epilepsy management and has pioneered several treatment protocols for stroke patients."
        },
        11: {
            name: "Dr. Nandini Joshi",
            image: "IMAGE/Doctor11.jpg",
            specialty: "Neurology",
            specialization: "Neurosurgeon",
            experience: "20 years",
            education: "MBBS, MS - General Surgery, MCh - Neurosurgery",
            expertise: "Brain surgeries, Tumor removal, Spinal surgeries",
            languages: "English, Hindi, Marathi",
            availability: "Tue, Thu: 10am-4pm (By appointment only)",
            about: "Dr. Nandini Joshi is a highly skilled neurosurgeon with 20 years of experience performing complex brain and spinal surgeries. She has received several awards for her contributions to the field of neurosurgery."
        },
        12: {
            name: "Dr. Riya Malhotra",
            image: "IMAGE/Doctor12.jpg",
            specialty: "Dermatology",
            specialization: "Dermatologist",
            experience: "12 years",
            education: "MBBS, MD - Dermatology",
            expertise: "Skin treatments, Acne management, Cosmetic dermatology",
            languages: "English, Hindi, Punjabi",
            availability: "Mon-Sat: 9am-5pm",
            about: "Dr. Riya Malhotra is a renowned dermatologist with 12 years of experience in medical and cosmetic dermatology. She has helped thousands of patients achieve healthier skin through personalized treatment plans."
        },
        13: {
            name: "Dr. Sameer Khan",
            image: "IMAGE/Doctor13.jpg",
            specialty: "Dermatology",
            specialization: "Cosmetic Dermatologist",
            experience: "8 years",
            education: "MBBS, MD - Dermatology, Fellowship in Cosmetic Dermatology",
            expertise: "Cosmetic procedures, Laser treatments, Anti-aging therapies",
            languages: "English, Hindi, Urdu",
            availability: "Mon-Fri: 10am-6pm",
            about: "Dr. Sameer Khan is a cosmetic dermatology specialist with 8 years of experience performing advanced aesthetic procedures. He is known for his artistic approach to cosmetic enhancements and natural-looking results."
        },
        14: {
            name: "Dr. Pooja Iyer",
            image: "IMAGE/Doctor14.jpg",
            specialty: "ENT",
            specialization: "ENT Specialist",
            experience: "9 years",
            education: "MBBS, MS - ENT",
            expertise: "Ear disorders, Sinus treatments, Thyroid surgery",
            languages: "English, Hindi, Tamil",
            availability: "Mon, Wed, Fri: 9am-4pm",
            about: "Dr. Pooja Iyer is an ENT specialist with 9 years of experience treating ear, nose, and throat disorders. She is particularly skilled in endoscopic sinus surgery and thyroid procedures."
        },
        15: {
            name: "Dr. Aditya Verma",
            image: "IMAGE/Doctor15.jpg",
            specialty: "ENT",
            specialization: "ENT Specialist",
            experience: "8 years",
            education: "MBBS, MS - ENT",
            expertise: "Voice disorders, Hearing problems, Nasal allergies",
            languages: "English, Hindi, Bengali",
            availability: "Tue, Thu, Sat: 10am-5pm",
            about: "Dr. Aditya Verma is an ENT specialist with 8 years of experience, particularly focused on voice disorders and hearing problems. He has helped many professional singers and speakers with voice rehabilitation."
        },
        16: {
            name: "Dr. Priya Kulkarni",
            image: "IMAGE/Doctor16.jpg",
            specialty: "ENT",
            specialization: "Audiologist",
            experience: "10 years",
            education: "BASLP, MASLP, PhD in Audiology",
            expertise: "Hearing disorders, Hearing aids, Cochlear implants",
            languages: "English, Hindi, Marathi",
            availability: "Mon-Fri: 9am-5pm",
            about: "Dr. Priya Kulkarni is an audiologist with 10 years of experience in diagnosing and treating hearing disorders. She has extensive expertise in hearing aid fittings and cochlear implant rehabilitation."
        },
        17: {
            name: "Dr. Sanjay Kapoor",
            image: "IMAGE/Doctor17.jpg",
            specialty: "Psychiatry",
            specialization: "Psychiatrist",
            experience: "10 years",
            education: "MBBS, MD - Psychiatry",
            expertise: "Mental health, Depression, Anxiety disorders",
            languages: "English, Hindi, Punjabi",
            availability: "Mon-Sat: 10am-5pm (By appointment)",
            about: "Dr. Sanjay Kapoor is a psychiatrist with 10 years of experience treating various mental health conditions. He takes a holistic approach to treatment, combining medication with therapy for best results."
        },
        18: {
            name: "Dr. Vikramathithan",
            image: "IMAGE/Doctor18.jpg",
            specialty: "Psychiatry",
            specialization: "Clinical Psychologist",
            experience: "12 years",
            education: "MA Psychology, PhD Clinical Psychology",
            expertise: "Psychological assessment, Therapy, Counseling",
            languages: "English, Hindi, Tamil",
            availability: "Mon-Fri: 9am-6pm",
            about: "Dr. Vikramathithan is a clinical psychologist with 12 years of experience providing therapy and counseling services. He specializes in cognitive behavioral therapy and has helped numerous patients overcome various psychological challenges."
        },
        19: {
            name: "Dr. Swathi Menon",
            image: "IMAGE/Doctor19.jpg",
            specialty: "Anesthesiology",
            specialization: "Anesthesiologist",
            experience: "15 years",
            education: "MBBS, MD - Anesthesiology",
            expertise: "General anesthesia, Regional anesthesia, Pain management",
            languages: "English, Hindi, Malayalam",
            availability: "Mon-Fri: 8am-4pm",
            about: "Dr. Swathi Menon is an experienced anesthesiologist with 15 years of expertise in providing safe and effective anesthesia for various surgical procedures. She is particularly skilled in regional anesthesia techniques."
        },
        20: {
            name: "Dr. Rahul Deshpande",
            image: "IMAGE/Doctor20.jpg",
            specialty: "Anesthesiology",
            specialization: "Pain Management Specialist",
            experience: "10 years",
            education: "MBBS, MD - Anesthesiology, Fellowship in Pain Management",
            expertise: "Chronic pain management, Interventional pain procedures",
            languages: "English, Hindi, Marathi",
            availability: "Mon, Wed, Fri: 9am-5pm",
            about: "Dr. Rahul Deshpande is a pain management specialist with 10 years of experience treating chronic pain conditions. He uses a multimodal approach including medications, interventions, and physical therapy to help patients manage pain effectively."
        },
        21: {
            name: "Dr. Rohit Khanna",
            image: "IMAGE/Doctor21.jpg",
            specialty: "Plastic Surgery",
            specialization: "Plastic Surgeon",
            experience: "12 years",
            education: "MBBS, MS - General Surgery, MCh - Plastic Surgery",
            expertise: "Reconstructive surgery, Burn surgery, Hand surgery",
            languages: "English, Hindi, Bengali",
            availability: "Tue, Thu: 10am-4pm (By appointment)",
            about: "Dr. Rohit Khanna is a plastic surgeon with 12 years of experience, specializing in reconstructive procedures for patients with burns, trauma, or congenital defects. He is known for his meticulous surgical technique and compassionate care."
        },
        22: {
            name: "Dr. Natasha Roy",
            image: "IMAGE/Doctor22.jpg",
            specialty: "Plastic Surgery",
            specialization: "Cosmetic Surgeon",
            experience: "8 years",
            education: "MBBS, MS - General Surgery, MCh - Plastic Surgery",
            expertise: "Cosmetic surgery, Breast augmentation, Rhinoplasty",
            languages: "English, Hindi, Bengali",
            availability: "Mon, Wed, Fri: 10am-5pm",
            about: "Dr. Natasha Roy is a cosmetic surgeon with 8 years of experience performing aesthetic procedures. She believes in natural-looking results and takes time to understand each patient's goals before recommending any procedure."
        },
        23: {
            name: "Dr. Ayesha Khan",
            image: "IMAGE/Doctor23.jpg",
            specialty: "Physiotherapy",
            specialization: "Physiotherapist",
            experience: "10 years",
            education: "BPT, MPT - Orthopedics",
            expertise: "Orthopedic physiotherapy, Post-operative rehabilitation",
            languages: "English, Hindi, Urdu",
            availability: "Mon-Sat: 8am-6pm",
            about: "Dr. Ayesha Khan is a physiotherapist with 10 years of experience helping patients recover from orthopedic injuries and surgeries. She develops personalized rehabilitation programs to ensure optimal recovery."
        },
        24: {
            name: "Dr. Varun Malhotra",
            image: "IMAGE/Doctor24.jpg",
            specialty: "Physiotherapy",
            specialization: "Sports Physio",
            experience: "4 years",
            education: "BPT, MPT - Sports Medicine",
            expertise: "Sports injuries, Athletic performance enhancement",
            languages: "English, Hindi, Punjabi",
            availability: "Mon-Fri: 9am-5pm",
            about: "Dr. Varun Malhotra is a sports physiotherapist with 4 years of experience working with athletes. He focuses not only on injury treatment but also on prevention and performance optimization."
        },
        25: {
            name: "Dr. Priyanka Chopra",
            image: "IMAGE/Doctor25.jpg",
            specialty: "Physiotherapy",
            specialization: "Rehabilitation specialist",
            experience: "6 years",
            education: "BPT, MPT - Neurology",
            expertise: "Neurological rehabilitation, Stroke recovery, Spinal cord injury rehab",
            languages: "English, Hindi, Marathi",
            availability: "Mon-Sat: 9am-4pm",
            about: "Dr. Priyanka Chopra is a rehabilitation specialist with 6 years of experience helping patients with neurological conditions regain function and independence. Her compassionate approach has helped many patients achieve remarkable recoveries."
        },
        26: {
            name: "Dr. Deepika Kapoor",
            image: "IMAGE/Doctor26.jpg",
            specialty: "General Medicine",
            specialization: "General Physician",
            experience: "10 years",
            education: "MBBS, MD - General Medicine",
            expertise: "General medicine, Chronic disease management, Preventive health",
            languages: "English, Hindi, Punjabi",
            availability: "Mon-Sat: 9am-5pm",
            about: "Dr. Deepika Kapoor is a general physician with 10 years of experience treating a wide range of medical conditions. She takes a comprehensive approach to patient care, focusing on both treatment and prevention."
        },
        27: {
            name: "Dr. Amit Sharma",
            image: "IMAGE/Doctor27.jpg",
            specialty: "General Medicine",
            specialization: "Family Medicine specialist",
            experience: "7 years",
            education: "MBBS, MD - Family Medicine",
            expertise: "Family medicine, Preventive care, Health screenings",
            languages: "English, Hindi",
            availability: "Mon-Fri: 8am-4pm",
            about: "Dr. Amit Sharma is a family medicine specialist with 7 years of experience providing comprehensive healthcare for patients of all ages. He believes in building long-term relationships with patients and their families."
        },
        28: {
            name: "Dr. Ravi Kumar",
            image: "IMAGE/Doctor28.jpg",
            specialty: "General Medicine",
            specialization: "Primary Care physician",
            experience: "6 years",
            education: "MBBS, MD - General Medicine",
            expertise: "Primary care, Health maintenance, Disease prevention",
            languages: "English, Hindi, Tamil",
            availability: "Mon-Sat: 9am-6pm",
            about: "Dr. Ravi Kumar is a primary care physician with 6 years of experience providing first-contact care for patients with various health concerns. He is known for his thorough assessments and patient education efforts."
        }
    };

// Doctor.js
document.getElementById('doctorModal').addEventListener('show.bs.modal', function (event) {
    const card = event.relatedTarget;
    const doctorId = card.getAttribute('data-doctor-id');
    const doctor = doctors[doctorId];
    
    if (doctor) {
        // Populate modal content
        document.getElementById('modal-doctor-img').src = doctor.image;
        document.getElementById('modal-doctor-name').textContent = doctor.name;
        document.getElementById('modal-specialty-badge').textContent = doctor.specialty;
        document.getElementById('modal-specialization').textContent = doctor.specialization;
        document.getElementById('modal-experience').textContent = doctor.experience;
        document.getElementById('modal-education').textContent = doctor.education;
        document.getElementById('modal-expertise').textContent = doctor.expertise;
        document.getElementById('modal-languages').textContent = doctor.languages;
        document.getElementById('modal-availability').textContent = doctor.availability;
        document.getElementById('modal-about').textContent = doctor.about;
        document.getElementById('doctorModalLabel').textContent = doctor.name + ' - Details';

        // ✅ Handle Book Appointment button click
        const bookBtn = document.getElementById('bookAppointmentBtn');
        if (bookBtn) {
            bookBtn.onclick = function () {
                // Save doctor + department in localStorage as JSON
                sessionStorage.setItem('selectedDoctor', doctor.name);
      sessionStorage.setItem('selectedDepartment', doctor.specialty);
                localStorage.setItem('selectedDoctorData', JSON.stringify({
                    name: doctor.name,
                    department: doctor.specialty
                }));

                // Redirect to Appointment page
                window.location.href = "Appointment.html";
            };
        }
    }
});

    // Filter functionality
    document.querySelectorAll('.filter-btn').forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            document.querySelectorAll('.filter-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Add active class to clicked button
            this.classList.add('active');
            
            const filter = this.getAttribute('data-filter');
            
            // Show/hide doctors based on filter
            document.querySelectorAll('.col[data-specialty]').forEach(doctorCol => {
                if (filter === 'all' || doctorCol.getAttribute('data-specialty') === filter) {
                    doctorCol.style.display = 'block';
                } else {
                    doctorCol.style.display = 'none';
                }
            });
        });
    });