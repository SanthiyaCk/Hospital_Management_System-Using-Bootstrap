// Make sure this only runs on pages with the contact form
if (document.getElementById('contactForm')) {
  document.addEventListener('DOMContentLoaded', function() {
    // Initialize EmailJS - REPLACE WITH YOUR ACTUAL PUBLIC KEY
    emailjs.init('mJy8HB4W1Msk3BDLD'); // Example: 'user_AbCdEfGhIjKlMnOpQrStUvW'
    
    const contactForm = document.getElementById('contactForm');
    const errorAlert = document.getElementById('errorAlert');
    const successAlert = document.getElementById('successAlert');
    const submitBtn = document.getElementById('submitBtn');
    const submitText = document.getElementById('submitText');
    const loadingSpinner = document.getElementById('loadingSpinner');
    
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Get and validate form values
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const message = document.getElementById('message').value.trim();
      
      if (!name || !email || !message) {
        showError('Please fill in all required fields.');
        return;
      }
      
      if (!validateEmail(email)) {
        showError('Please enter a valid email address.');
        return;
      }
      
      // Show loading state
      submitText.textContent = 'Sending...';
      loadingSpinner.classList.remove('d-none');
      submitBtn.disabled = true;
      hideAlerts();
      
      // Send email - REPLACE THESE WITH YOUR ACTUAL IDs
      emailjs.send(
        'service_bxbd4li', // Your EmailJS Service ID
        'template_rol5etp', // Your EmailJS Template ID
        {
          from_name: name,
          from_email: email,
          message: message,
          to_email: 'santhiyasanthiya88838@gmail.co ' // Hospital's real email
        }
      )
      .then(function() {
        showSuccess('Message sent successfully!');
        contactForm.reset();
        showModal();
      })
      .catch(function(error) {
        showError(`Failed to send: ${error.text || 'Please try again later.'}`);
      })
      .finally(function() {
        submitText.textContent = 'Send Message';
        loadingSpinner.classList.add('d-none');
        submitBtn.disabled = false;
      });
    });
    
    // Helper functions
    function validateEmail(email) {
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return re.test(email);
    }
    
    function showError(message) {
      errorAlert.textContent = message;
      errorAlert.classList.remove('d-none');
    }
    
    function showSuccess(message) {
      successAlert.textContent = message;
      successAlert.classList.remove('d-none');
    }
    
    function hideAlerts() {
      errorAlert.classList.add('d-none');
      successAlert.classList.add('d-none');
    }
    
    function showModal() {
      const modal = new bootstrap.Modal(document.getElementById('feedbackSuccessModal'));
      modal.show();
    }
  });
}