const container = document.getElementById('emergencyCards');
const cardWidth = 300; // card width + gap
let autoScrollInterval;

function scrollEmergency(direction) {
  container.scrollBy({
    left: direction * cardWidth,
    behavior: 'smooth'
  });
}

// Auto-scroll every 3 seconds
function startAutoScroll() {
  autoScrollInterval = setInterval(() => {
    if (container.scrollLeft + container.clientWidth >= container.scrollWidth) {
      // If at the end → go back to start
      container.scrollTo({ left: 0, behavior: 'smooth' });
    } else {
      scrollEmergency(1);
    }
  }, 3000); // 3 sec
}

// Pause auto-scroll on hover
container.addEventListener('mouseenter', () => clearInterval(autoScrollInterval));
container.addEventListener('mouseleave', startAutoScroll);

// Start auto-scroll when page loads
startAutoScroll();


// Emergency data
    const emergencies = {
        'chest-pain': {
            title: "Chest Pain",
            image: "IMAGE/Checkpain.jpg",
            type: "Cardiac/Cardiovascular",
            severity: "High - Life Threatening",
            actions: "Call emergency immediately. Stay calm and sit down. Chew aspirin if not allergic.",
            whenToSeek: "Immediately for any chest pain, especially with sweating, nausea, or shortness of breath",
            description: "Chest pain can be a sign of a heart attack, which requires immediate medical attention. Symptoms may include pressure, squeezing, or pain in the center of the chest that lasts more than a few minutes or goes away and comes back."
        },
        'breathing-difficulty': {
            title: "Difficulty Breathing",
            image: "IMAGE/BreathingDifficulty.jpg",
            type: "Respiratory",
            severity: "High - Life Threatening",
            actions: "Call emergency. Stay calm and sit upright. Use inhaler if available.",
            whenToSeek: "Immediately for sudden severe shortness of breath, especially with chest pain, fainting, or nausea",
            description: "Difficulty breathing can indicate serious conditions like asthma attacks, pneumonia, pulmonary embolism, or heart problems. If breathing is severely compromised, emergency care is critical."
        },
        'uncontrolled-bleeding': {
            title: "Uncontrolled Bleeding",
            image: "IMAGE/Uncontrolbleeding.jpg",
            type: "Trauma",
            severity: "High - Life Threatening",
            actions: "Apply direct pressure with a clean cloth. Elevate the wound if possible. Do not remove soaked bandages.",
            whenToSeek: "Immediately for bleeding that won't stop after 10 minutes of direct pressure",
            description: "Uncontrolled bleeding can lead to shock and death if not treated promptly. Deep wounds, arterial bleeding (spurting blood), or large blood loss require emergency care."
        },
        'stroke': {
            title: "Stroke Symptoms",
            image: "IMAGE/Stroke.jpg",
            type: "Neurological",
            severity: "High - Life Threatening",
            actions: "Call emergency immediately. Note the time symptoms started. Do not give food or drink.",
            whenToSeek: "Immediately for any signs of stroke using the FAST test: Face drooping, Arm weakness, Speech difficulty, Time to call emergency",
            description: "A stroke occurs when blood flow to the brain is interrupted. Quick treatment is crucial to prevent permanent brain damage. Symptoms include sudden numbness, confusion, trouble speaking, vision problems, or severe headache."
        },
        'severe-burns': {
            title: "Severe Burns",
            image: "IMAGE/Severe_Burn.jpg",
            type: "Trauma",
            severity: "High - Requires Immediate Care",
            actions: "Call emergency. Cool the burn with cool (not cold) water. Do not apply ice. Cover with clean cloth.",
            whenToSeek: "Immediately for burns that are large, deep, on face, hands, feet, or genitals, or caused by chemicals or electricity",
            description: "Severe burns can cause shock, infection, and permanent tissue damage. Third-degree burns (white or charred skin, no pain in burned area) always require emergency treatment."
        },
        'seizures': {
            title: "Seizures",
            image: "IMAGE/Seizures.jpg",
            type: "Neurological",
            severity: "High - Requires Immediate Care",
            actions: "Call emergency if seizure lasts more than 5 minutes or person has difficulty breathing. Protect from injury, do not restrain.",
            whenToSeek: "Immediately for first-time seizures, seizures lasting more than 5 minutes, or multiple seizures without regaining consciousness",
            description: "Seizures can be caused by various conditions including epilepsy, head injury, or infections. Status epilepticus (prolonged seizure) is a medical emergency that can cause brain damage."
        },
        'loss-of-consciousness': {
            title: "Loss of Consciousness",
            image: "IMAGE/Loss_Consciousness.png",
            type: "Neurological/Cardiac",
            severity: "High - Requires Immediate Care",
            actions: "Call emergency. Check breathing and pulse. If trained, begin CPR if necessary.",
            whenToSeek: "Immediately for any unexplained loss of consciousness, especially with chest pain, shortness of breath, or head injury",
            description: "Loss of consciousness can indicate serious conditions like heart problems, stroke, severe dehydration, or neurological issues. Even brief fainting spells should be evaluated if they're unusual for the person."
        },
        'severe-allergy': {
            title: "Severe Allergic Reaction",
            image: "IMAGE/Severe_Allergy.jpeg",
            type: "Allergic/Immunological",
            severity: "High - Life Threatening",
            actions: "Use epinephrine auto-injector if available. Call emergency even if symptoms improve.",
            whenToSeek: "Immediately for difficulty breathing, swelling of face/throat, rapid heartbeat, or dizziness after potential allergen exposure",
            description: "Anaphylaxis is a severe allergic reaction that can be fatal without prompt treatment. Symptoms may include hives, swelling, wheezing, and shock. Even if symptoms seem to improve after epinephrine, emergency care is still needed."
        },
        'high-fever': {
            title: "Very High Fever",
            image: "IMAGE/High_Fever.jpg",
            type: "Infectious",
            severity: "Moderate to High",
            actions: "Seek emergency for fevers with stiff neck, confusion, seizure, or severe headache. Use fever reducers as directed.",
            whenToSeek: "Immediately for fever above 104°F (40°C) in adults or children, especially with other severe symptoms",
            description: "Very high fevers can indicate serious infections or heat stroke. In children, high fevers can sometimes cause seizures. Fevers with rash, confusion, or stiff neck may indicate meningitis."
        },
        'persistent-vomiting': {
            title: "Persistent Vomiting",
            image: "IMAGE/Persistent_Vomiting.jpeg",
            type: "Gastrointestinal",
            severity: "Moderate to High",
            actions: "Seek emergency for vomiting blood, severe abdominal pain, or signs of dehydration. Try small sips of clear fluids.",
            whenToSeek: "Immediately for vomiting blood, severe abdominal pain, dehydration (dry mouth, no urine), or vomiting lasting more than 24 hours",
            description: "Persistent vomiting can lead to dangerous dehydration and electrolyte imbalances. Vomiting blood may indicate internal bleeding. Severe abdominal pain with vomiting could be appendicitis or bowel obstruction."
        },
        'severe-injury': {
            title: "Severe Injuries",
            image: "IMAGE/Severe_Injury.jpg",
            type: "Trauma",
            severity: "High - Requires Immediate Care",
            actions: "Call emergency. Keep injured person still. Do not move unless necessary for safety.",
            whenToSeek: "Immediately for major trauma, suspected broken bones, deep wounds, or head injuries with loss of consciousness",
            description: "Severe injuries from accidents, falls, or violence require emergency evaluation. Internal injuries may not be immediately apparent. Head injuries can cause delayed symptoms but need prompt assessment."
        },
        'poisoning': {
            title: "Poisoning",
            image: "IMAGE/Poisoning.jpg",
            type: "Toxicological",
            severity: "High - Life Threatening",
            actions: "Call poison control (1-800-222-1222) or emergency. Do not induce vomiting unless instructed.",
            whenToSeek: "Immediately for any suspected poisoning, especially with difficulty breathing, confusion, or unconsciousness",
            description: "Poisoning can occur from ingestion, inhalation, or skin contact with toxic substances. Symptoms vary based on the poison but may include nausea, difficulty breathing, confusion, or seizures. Bring the poison container to the hospital if possible."
        }
    };

    const emergencyModal = new bootstrap.Modal(document.getElementById('emergencyModal'));

    // Show emergency details in modal
    function showEmergencyDetails(emergencyType) {
        const emergency = emergencies[emergencyType];
        
        if (emergency) {
            document.getElementById('modal-emergency-img').src = emergency.image;
            document.getElementById('modal-emergency-title').textContent = emergency.title;
            document.getElementById('modal-emergency-type').textContent = emergency.type;
            document.getElementById('modal-severity').textContent = emergency.severity;
            document.getElementById('modal-actions').textContent = emergency.actions;
            document.getElementById('modal-when-to-seek').textContent = emergency.whenToSeek;
            document.getElementById('modal-description').textContent = emergency.description;
            document.getElementById('emergencyModalLabel').textContent = emergency.title + ' - Emergency Information';
            
            emergencyModal.show();
        }
    }

    // Call emergency function
    function callEmergency() {
        alert("Emergency services would be contacted. In a real application, this would dial the local emergency number.");
        // In a real application, this would be: window.location.href = 'tel:911';
    }